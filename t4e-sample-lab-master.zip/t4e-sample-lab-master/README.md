This is a sample template of the directory structure of a Virtual Lab
